import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-database-backup',
  templateUrl: './create-database-backup.component.html',
  styleUrls: ['./create-database-backup.component.scss']
})
export class CreateDatabaseBackupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  add(name:HTMLInputElement){

  }

  close(){

  }
}
