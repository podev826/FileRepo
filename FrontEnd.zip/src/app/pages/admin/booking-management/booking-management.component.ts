import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-management',
  templateUrl: './booking-management.component.html',
  styleUrls: ['./booking-management.component.scss']
})
export class BookingManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
