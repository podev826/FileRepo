export interface AuthStoreModel {
  token: string;
  admin: boolean;
  userId: number;
}
