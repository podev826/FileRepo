export interface EmployeeType {
  employeeTypeId: number;
  employeeTypeName: string;
  employeeTypeDescription: string;
}
