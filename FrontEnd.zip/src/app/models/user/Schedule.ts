export interface Schedule {
  scheduleId: number;
  date: Date;
}
