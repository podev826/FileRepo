export interface MakeBookingModel {
  date: string;
  serviceId: number;
  staffMemberId: number;
  timeSlotId: number;
  userId: number;
}
