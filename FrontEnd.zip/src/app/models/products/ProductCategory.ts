export interface ProductCategory {
  productCategoryId: number;
  productCategoryName: string;
  productCategoryDescription: string;
  imgUrl: string;
}
