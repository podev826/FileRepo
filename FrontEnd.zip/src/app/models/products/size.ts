export interface Size {
  sizeId: number;
  sizeName: string;
}
