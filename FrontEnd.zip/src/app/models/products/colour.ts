export interface Colour {
  colourId: number;
  colourName: string;
}
