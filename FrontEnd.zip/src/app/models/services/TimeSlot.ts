export interface TimeSlot {
  timeslotId: number;
  startTime: Date;
  endTime: Date;
  available: boolean;
}
