export interface ServiceCategory {
  serviceCategoryId: number;
  serviceCategoryName: string;
  serviceCategoryDescription: string;
  imgUrl: string;
}
