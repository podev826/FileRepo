export interface OrderStatus {
  orderStatusId: number;
  orderStatusName: string;
}
