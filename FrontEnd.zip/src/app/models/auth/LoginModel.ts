export interface LoginModel {
  UserName: string;
  Password: string;
}
