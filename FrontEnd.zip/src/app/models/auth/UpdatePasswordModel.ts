export interface updatePasswordModel {
  email: string;
  oldPassword: string;
  newPassword: string;
}
