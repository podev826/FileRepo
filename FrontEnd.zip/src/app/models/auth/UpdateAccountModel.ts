export interface UpdateAccountModel {
  username: string;
  firstname: string;
  lastname: string;
  email: string;
  contact: string;
  picture: string;
}
