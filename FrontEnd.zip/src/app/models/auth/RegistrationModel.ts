export interface RegistrationModel {
  username: string;
  password: string;
  firstname: string;
  lastname: string;
  email: string;
  contact: string;
  picture: string;
}
