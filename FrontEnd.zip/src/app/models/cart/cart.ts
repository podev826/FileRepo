export interface Cart {
  CartId: number;
  CartTotal: number;
  UserId: number;
}
