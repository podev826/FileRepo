﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class NotificationType
    {

        public int NotificationTypeId { get; set; }
        public string NotificationTypeName { get; set; }

    }
}
