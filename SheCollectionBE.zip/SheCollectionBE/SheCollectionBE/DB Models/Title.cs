﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class Title
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
    }
}
