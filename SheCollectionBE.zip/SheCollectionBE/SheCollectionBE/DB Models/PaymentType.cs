﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class PaymentType
    {
        public int PaymentTypeId { get; set; }
        public string PaymentTypeName { get; set; }
    }
}
