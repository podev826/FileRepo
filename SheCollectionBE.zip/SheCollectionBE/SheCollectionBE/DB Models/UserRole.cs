﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class UserRole
    {
        public int UserRoleId { get; set; }
        public string UserRoleName { get; set; }
    }
}
