﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class BookingStatus
    {
        public int BookingStatusId { get; set; }
        public string BookingStatusName { get; set; }

    }
}
