﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class Schedule
    {
        public int ScheduleId { get; set; }
        public DateTime Date { get; set; }
    }
}
