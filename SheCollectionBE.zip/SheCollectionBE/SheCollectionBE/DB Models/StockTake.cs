﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class StockTake
    {
        public int StockTakeId { get; set; }
        public DateTime StockTakeDate { get; set; }
    }
}
