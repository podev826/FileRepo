﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class EmployeeType
    {

        public int EmployeeTypeId { get; set; }
        public string EmployeeTypeName { get; set; }
        public string EmployeeTypeDescription { get; set; }
    }
}
