﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class SalesStatus
    {
        public int SalesStatusId { get; set; }
        public string SalesStatusName { get; set; }
    }
}
