﻿using System;
using System.Collections.Generic;

namespace SheCollectionBE.Models
{
    public partial class DateTable
    {
        public int DateTableId { get; set; }
        public DateTime AvailableDate { get; set; }
    }
}
