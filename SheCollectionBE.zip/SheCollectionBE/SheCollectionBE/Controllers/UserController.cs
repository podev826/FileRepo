﻿namespace SheCollectionBE.Controllers
{
    public class UserController : BaseController
    {
        
    }
}
