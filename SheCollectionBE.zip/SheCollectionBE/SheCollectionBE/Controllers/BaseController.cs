﻿using Microsoft.AspNetCore.Mvc;

namespace SheCollectionBE.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BaseController : Controller
    {
    }
}
