﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.EmployeeService
{
    public interface IEmployeeService : IService<Employee>
    {
    }
}
