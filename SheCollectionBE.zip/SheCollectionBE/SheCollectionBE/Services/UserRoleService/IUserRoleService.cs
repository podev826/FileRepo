﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.UserRoleService
{
    public interface IUserRoleService : IService<UserRole>
    {
    }
}
