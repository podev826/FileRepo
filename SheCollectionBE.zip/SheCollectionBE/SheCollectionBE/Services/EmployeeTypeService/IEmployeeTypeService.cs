﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.EmployeeTypeService
{
    public interface IEmployeeTypeService :IService<EmployeeType>
    {
    }
}
