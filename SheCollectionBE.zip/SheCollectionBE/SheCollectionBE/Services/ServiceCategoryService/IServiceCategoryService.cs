﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.ServiceCategoryService
{
    public interface IServiceCategoryService : IService<ServiceCategory>
    {
    }
}
