﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.ColourService
{
    public interface IColourService : IService<Colour>
    {
    }
}
