﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.TitleService
{
    public interface ITitleService : IService<Title>
    {
    }
}
