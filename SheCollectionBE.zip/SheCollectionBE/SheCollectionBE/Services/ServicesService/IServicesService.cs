﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.ServicesService
{
    public interface IServicesService :IService<ServiceTable>
    {
    }
}
