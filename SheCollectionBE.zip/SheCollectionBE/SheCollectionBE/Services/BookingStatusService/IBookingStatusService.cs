﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.BookingStatusService
{
    public interface IBookingStatusService : IService<BookingStatus>
    {
    }
}
