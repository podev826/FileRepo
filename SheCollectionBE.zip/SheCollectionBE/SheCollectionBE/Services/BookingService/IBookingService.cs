﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.BookingService
{
    public interface IBookingService : IService<Booking>
    {
    }
}
