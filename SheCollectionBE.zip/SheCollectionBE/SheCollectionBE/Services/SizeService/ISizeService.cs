﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.SizeService
{
    public interface ISizeService : IService<Size>
    {
    }
}
