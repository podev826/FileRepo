﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.OrderService
{
    public interface IOrderService : IService<OrderTable>
    {
    }
}
