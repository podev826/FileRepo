﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.ScheduleService
{
    public interface IScheduleService : IService<Schedule>
    {
    }
}
