﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.EmployeeScheduleService
{
    public interface IEmployeeScheduleService: IService<EmployeeSchedule>
    {
    }
}
