﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.ServiceTypeService
{
    public interface IServiceTypeService : IService<ServiceType>
    {
    }
}
