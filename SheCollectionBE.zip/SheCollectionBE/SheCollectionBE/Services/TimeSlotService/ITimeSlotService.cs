﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.TimeSlotService
{
    public interface ITimeSlotService : IService<Timeslot>
    {
    }
}
