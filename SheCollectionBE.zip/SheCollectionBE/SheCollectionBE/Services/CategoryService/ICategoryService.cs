﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.CategoryService
{
    public interface ICategoryService : IService<ProductCategory>
    {
    }
}
