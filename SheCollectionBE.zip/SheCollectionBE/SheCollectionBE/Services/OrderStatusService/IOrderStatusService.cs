﻿using SheCollectionBE.Models;

namespace SheCollectionBE.Services.OrderStatusService
{
    public interface IOrderStatusService : IService<OrderStatus>
    {
    }
}
